//booksLibrary.js

//three classes: Library, Shelf, and Book

function Library()
{
    //types of books: 5 reference, 20 ordinary
    //reference books cannot be checked out
}

Library.prototype.foo = function()
{

}

function Book()
{
    this.id = id;
    this.type = type; //reference, ordinary
    this.category = category;
    //art, science, sport, literature
    //TODO id % 4 (0=art, 1= science, 2=sport, 3=literature)
    //different shelf for each category
    this.borrowedBy = borrowedBy;
    //the username of student who borrowed book, at first borrowedBy none of the students
    this.presence = presence;
    //presence(1) or borrowed(0) situation of book, at first all books are presence
    //TODO use local storage in order to save presence and borrowedBy attribute for each book

}
