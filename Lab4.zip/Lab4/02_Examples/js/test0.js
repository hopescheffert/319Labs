console.log(i++, " in test0.js ",new Date().getTime());
