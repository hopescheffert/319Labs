package messenger;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * Waits whole time for the client to send it a message
 * "Client Listener"
 * @author hopees
 *
 */
public class ServerListenForClientMessage implements Runnable 
{
	Scanner in; //blocking call
	Socket s;
	Client c;
	
	ServerListenForClientMessage(Client c, Socket s) throws IOException
	{
		//scanner from output of the server
		in = new Scanner(new BufferedInputStream(s.getInputStream()));
		this.s = s;
		this.c = c;
	}
	
	
	@Override
	public void run() 
	{
		Scanner console;
		PrintWriter out;
		
		while(true) //run forever
		{
			// 1. USE THE SOCKET TO READ WHAT THE CLIENT IS SENDING?
			//in = new Scanner(new BufferedInputStream(s.getInputStream())); 
			console = new Scanner(new BufferedInputStream(System.in)); 
			try {
				out = new PrintWriter(new BufferedOutputStream(s.getOutputStream()));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//out = new PrintWriter(s.getOutputStream());
			//display menu to client
			System.out.println("What would you like to do? "
					+ "Please choose 1 or 2 and press enter:");
			System.out.println("1. Send a text message to the server");
			System.out.println("2. Send an image file to the server");

			//keep listening and responding to client requests

		
			int choice = console.nextInt();
			Thread t = new Thread(new ServerHandleClient(s, c.username, choice));
			t.start();

		}
		
		
	}
	
	public void handleMessage()//(String msg)
	{
		Thread t = new Thread(new ServerGetMessageFromClient(s, c.username));
		t.start();
	}

}