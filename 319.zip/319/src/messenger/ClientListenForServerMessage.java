package messenger;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
/**
 * "Server Listener"
 * @author hopescheffert
 *
 */
public class ClientListenForServerMessage implements Runnable 
{
	Client c;
	Scanner in; //blocking call
	Socket s;


	ClientListenForServerMessage(Client c, Socket s) throws IOException
	{
		this.c = c;
		//scanner from output of the server
		in = new Scanner(new BufferedInputStream(s.getInputStream()));
		this.s = s;
	
	}

	/**
	 * Sole purpose is to listen for a message from the server at all times
	 */
	@Override
	public void run() 
	{
		Scanner console;
		PrintWriter out;
		
		while(true) //run forever
		{
			

		}

	}

}