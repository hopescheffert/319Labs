package messenger;


import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.Scanner;

public class ClientSendMessageToServer  
{
	private Socket s;
	private String clientName;
	private String msg;

	public ClientSendMessageToServer(Socket s, String username)//, String msg)
	{
		this.s = s;
		clientName = username;
		//this.msg = msg;

	}

	public void go() 
	{
		//get the message from the client
		String clientTextMessage;
		System.out.println("Please type your text message and press enter");
		Scanner console = new Scanner(new BufferedInputStream(System.in));

		while(console.hasNextLine())
		{
			clientTextMessage = console.nextLine();


			//send message to encryption method using a printwriter and outputstream
			try 
			{
				String encryptedMessage = encryptMessage(clientTextMessage);
				//String encryptedMessage = encryptMessage(message); //get encrypted message
				//String encryptedMessage = encryptMessage(msg);
				//send to server
				PrintWriter out = new PrintWriter(s.getOutputStream()); //new BufferedOutputStream(s.getOutputStream()));

				out.write(encryptedMessage.length()); //write length of the message (an int)
				out.write(encryptedMessage); //write the message
				out.flush(); //forces output

			} catch (UnsupportedEncodingException e) 
			{
				System.out.println("----Problem with encrypting the message");
				e.printStackTrace();
			} catch (IOException e) 
			{
				e.printStackTrace();
			}

		}
	}

	/**
	 * MESSAGE
	 * Gets the client's text message and outputs an encrypted byte array 
	 * Method of Encryption:
	 * For every byte Bn in a String, encrypted Byte = Bn XOR 11110000
	 * e.g. Bn = 10101000, then Bn Xor 11110000 = 01011000
	 * @throws UnsupportedEncodingException 
	 */
	public String encryptMessage(String message) throws UnsupportedEncodingException
	{
		byte[] encryptedBytes = message.getBytes();
		for(int i = 0; i < encryptedBytes.length; i ++)
		{
			//do XOR with 11110000
			encryptedBytes[i] = (byte) (encryptedBytes[i] ^ 11110000);
		}

		return new String(encryptedBytes);
	}

	/**
	 * IMAGE
	 * Method of Encryption:
	 * Suppose an image is stored by m bytes
	 * 
	 * For every 3 bytes, we have 24 bits
	 * 		Divide 24 into four 6 bit fragments
	 * 		Add two bits of 00 to the right of each 6 bits fragment
	 * 		(then we can get four 8 bit fragments)
	 * 		Convert the 8 bit fragments into characters and combine them to make a string
	 * 
	 * @param path
	 * @return
	 */
	public byte[] encryptImage(String path)
	{
		byte[] encryptedBytes = path.getBytes();
		int len = encryptedBytes.length;
		//for every 3 bytes

		for(int i = 0; i < len % 3; i++)
		{
			//TODO encrypt!

		}

		return encryptedBytes;

	}
}