package messenger;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.util.Scanner;

class ServerHandleClient implements Runnable {
	private static Socket s; // this is socket on the server side that connects to the CLIENT
	private String username;
	private int choice;

	ServerHandleClient(Socket s, String username, int choice)
	{
		this.s = s;
		this.username = username;
		this.choice = choice;

	}


	// This is the client handling code
	// This keeps running handling client requests 
	// after initially sending some stuff to the client
	@Override
	public void run() 
	{

		if(choice == 1) //wants to send a message
		{
			//TODO make sure message goes to chat.txt

			//send to a new thread to deal with client sending message
//			ClientSendMessageToServer csm = new ClientSendMessageToServer(s, username);
//			csm.go();
		}


		//****IMAGE*****			

		else if(choice == 2) //wants to send an image
		{
			//TODO will look something like this:
			//Thread t = new Thread(new ClientSendImage(s));
			//t.start();
			//TODO put this in new class called ClientSendImage implements Runnable
			//TODO send an image file to the server using java's object output stream
			try {
				ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());

				//Object ob = new Object();
				//oos.writeObject(ob);

				//stuff here

				//oos.close();

			} catch (IOException e) {
				e.printStackTrace();
			}

			//ask client to enter the file name of the image
			System.out.println("Please enter your image file name and press enter");
			Scanner img = new Scanner(System.in);
			String imgpath = img.nextLine();
			img.close();
			//TODO convert image to a string sequence and encrypt that
			//send it to encryption method
			//byte[] encryptedImage = encryptImage(imgpath);


			//get image from the client
			try 
			{
				ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
				//Object ob1 = ois.readObject();

				//stuff here

				//ois.close();


			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		else
		{ System.out.println("Please enter either 1 or 2");}


	} // end of method run()


} // end of class ClientHandler