//War.JS

//http://www.brainjar.com/js/cards/default2.asp	

var War = 
{

	Model :  
	{
	    //create a card object 
	    //Ex. value="2", suit= "Clubs", img= "2c" for 2 of Clubs with the 2 of clubs image
	    makeCard : function Card(value, suit, img)
	    {
		    this.value = value;
		    this.suit = suit;
		    this.img = "<img id='" + img + "' src='/Users/hopescheffert/Documents/COMS319/WarGame/cards/" +img+ ".gif'</img>";
	    },
		//create a deck of 52 cards
		makeDeck : function()
        {
            // Jack = 11, Queen = 12, King = 13, Ace = 14
            this.names = ['2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14'];
            this.suits = ['Hearts', 'Diamonds', 'Spades', 'Clubs'];
            this.imgname = ['h', 'd', 's', 'c'];
            
            var deck = [];
            for(var suit = 0; s < this.suits.length; suits++)
            {
                for(var img = 0; img < this.imgname.length; img ++)
                {
                
                    for(var name = 2; n <= this.names.length; names++)
                    {
                          deck.push(War.Model.makeCard(names, this.names[name], this.suits[suit]), i+this.imgname[img]);
                    }
                }
            }
            return deck;
        },
		//shuffle deck
		shuffleCards : function(cards)
		{
		    //shuffle 3 times
		    for(var i = 0; i < 3; i++)
		    {
			    //go through cards and randomly switch around
			    for(var j = 0; j < cards.length; j++)
			    {
			    	var r = Math.floor(Math.random() * cards.length);
			    	var temp = cards[j];
			    	cards[j] = cards[k];
			    	cards[k] = temp;
		    	}
		    }   
		    //returns shuffled cards
		    return cards;
		},
		
		dealPlayer : function(deck)
        {
            var hand = [];
            //shuffle the deck first to ensure its randomly dealing cards
            deck = War.Model.shuffleCards(deck);
            for(var i = 0; i < deck.length/2; i++)
            {
                //push one card to the hand
                hand.push(deck[i]);
                //remove that card from the deck
                deck.shift();
            }
            //returns one player's hand, also will decrement the deck by 26 cards after called once
            return hand;    
        }
		    
	},


	View : 
	{
	  startButton : {id: "startButton", type: "button", value: "Start Game", onclick:""},
	  quitButton : {id: "quitButton", type: "button", value: "Quit Game", onclick:""},
	  takeTurnButton : {id: "takeTurnButton", type: "button", value: "Lay Down A Card", onclick:""},
	  score : {id: "score", value: ""},
	  playerCardDown : {id: "playerCardDown", src: "/Users/hopescheffert/Documents/COMS319/WarGame/cards/back.gif"},
	  playerCardUp : {id: "playerCardUp", src: ""},
	},

	Controller : 
	{
	    //onclick for start button to begin the game
		startButtonHandler : function() 
		{
		    //makes deck and shuffles the cards
		    deck = War.Model.makeDeck;
		    deck = War.Model.shuffleCards(deck);
		    
		    
		    //deal computer 26 cards
		    computerHand = [];
		    computerHand = War.Model.dealPlayer(deck);
		    //deal player 26 cards
		    playerHand = [];
		    playerHand = War.Model.dealPlayer(deck);
		    //display score to begin with
		    War.Controller.getScore();

		},
		//onclick for quit button to end/restart the game
		quitButtonHandler : function()
		{
		    //TODO stops game...resets everything?
		},
		//onclick for taking turn button aka laying down a card...to be compared
		takeTurnButtonHandler: function()
		{
		    //lay one card from hand face down, the other face up.
		    if(playerHand.length < 2)
		    {   
		        //TODO in this case, the computer wins...game over
		    }
		    if(computerHand.length < 2)
		    {
		        //TODO in this case, the player wins...game over
		    }
		    
		        //lay one card face down
		        var layDown = playerHand.shift();
		        //TODO display this card on the board?
		        playerCardDown = "War.displayCardElement(layDown)";
		        //lay one card face up
		        var layUp = playerHand.shift();
		        //TODO display this card on the board?
		        playerCardUp.src = layUp.img;
		        
		        //this layUp card now needs to be compared with opponents layUp card
		        if(playerHand.layUp.value > computerHand.layUp.value)
		        {
		            //TODO player wins this round and takes all four cards
		                
		        }
		        else if(playerHand.layUp.value < computerHand.layUp.value)
		        {
		            //TODO computer wins this round and takes all four cards
		        }
		        else
		        {
		            //TODO WAR (call takeTurnHandler again?
		        }
		            
		    
		},
		getScore : function()
	    {
	        //show player score and computer score
	         War.View["score"].value = "Your Score: " + playerHand.length() + " cards <br>" +
	                            "Computer Score:  " + computerHand.length() + " cards <br>";
	    
	    }

	},

	run : function() 
	{
	  War.attachHandlers();
	  War.Controller.getScore();
	  console.log(War.displayAll());
	  return War.displayAll();
	},

	displayAll : function() 
	{
	  var s= "<h1>Welcome to War!<h1>";
      s += War.displayDivElement(War.View.score);
	  s += "<br>";
	  s += War.displayInputElement(War.View.startButton);
	  s+= "<br>";
	  s += War.displayInputElement(War.View.takeTurnButton);
	  s+= "<br>";
	  s += War.displayInputElement(War.View.quitButton);
	  s+= "<br>";
	  return s;
	},
	//displaying card
	displayCardElement : function (element) 
	{
	  var s = "<img ";
	  s += " id=\"" + element.id + "\"";
	  s += " src= \"" + element.src + "\"";
	  s += " height=102 width=73";
	  s += ">";
	  return s;

	},
    //displaying buttons
	displayInputElement : function (element) 
	{
	  var s = "<input ";
	  s += " id=\"" + element.id + "\"";
	  s += " type=\"" + element.type + "\"";
	  s += " value= \"" + element.value + "\"";
	  s += " onclick= \"" + element.onclick + "\"";
	  s += ">";
	  return s;

	},
	//displaying a div element: SCORE
	displayDivElement : function (element) 
	{
	  var s = "<div ";
	  s += " id=\"" + element.id + "\"";
	  s += " value= \"" + element.value + "\"";
	  s += ">";
	  return s;

	},

	attachHandlers : function() 
	{
	    War.View["startButton"].onclick ="War.Controller.startButtonHandler()";
	    War.View["quitButton"].onclick ="War.Controller.quitButtonHandler()";
	    War.View["takeTurnButton"].onclick ="War.Controller.takeTurnButtonHandler()";
	    War.View["score"].value = "War.Controller.getScore()";
	}
	


} // end of War;


